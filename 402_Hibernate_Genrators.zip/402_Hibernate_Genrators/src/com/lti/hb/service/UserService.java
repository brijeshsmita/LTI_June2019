package com.lti.hb.service;

import com.lti.hb.exception.UserException;
import com.lti.hb.model.User;

public class UserService implements IUserService {
//prep work 1 - Object of Dao
	@Override
	public User getUserById(Integer userId) throws UserException {
		//prep work 2 - call method of Dao and return
		return null;
	}

}
