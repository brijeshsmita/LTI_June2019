package com.lti.hb.service;
import com.lti.hb.exception.UserException;
import com.lti.hb.model.User;
/**
 * @author Smita
 *
 */
public interface IUserService {
	public abstract User getUserById(Integer userId)throws UserException;
}




