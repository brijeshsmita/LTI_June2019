package com.lnt.day18_hibernate.customer.model;

import java.io.Serializable;

/*
 *   create table  lnt_customer
  (	
		cust_Id long primary key ,
		cust_Name varchar2(20),
		email varchar2(20),
		phone varchar2(20)
 );
 */
//XML- eXtensible markup language ,a standard or a specification, which is used to describe data in a heterogeneous enviornment 
//persist the customer object into DB
// configure db connectivity details -> Session Factory hibernate.cfg.xml 
//customer object details as well customer table details -> customer.hbm.xml
public class Customer implements Serializable{
	private static final long serialVersionUID = -4822203003035741119L;
	private Long custId;
	private String custName;
	private String email;
	private String phone;
//contructors, getters and setters, equals, toString, hashCode
	public Customer() {
		super();
	}

	public Customer(Long custId, String custName, String email, String phone) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.email = email;
		this.phone = phone;
	}

	public Long getCustId() {
		return custId;
	}

	public void setCustId(Long custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", email=" + email + ", phone=" + phone + "]";
	}

}
