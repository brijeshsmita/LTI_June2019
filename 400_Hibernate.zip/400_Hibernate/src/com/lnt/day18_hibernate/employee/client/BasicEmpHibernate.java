/**
 * 
 */
package com.lnt.day18_hibernate.employee.client;

import java.sql.SQLException;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lnt.day18_hibernate.util.MyHibernateUtil;

/**
 * @author brije
 *
 */
public class BasicEmpHibernate {
	private static SessionFactory sessionFactory;
	private static Session session;
	private static Transaction transaction;
	private static Employee employee ;
	/*private static Connection conn;
	private static Statement stmt = null;
	private static PreparedStatement ps = null;
	private static ResultSet rs = null;*/
	private static Scanner scan = new Scanner(System.in);
	static {
		/*conn = MyConnection.getConn();*/
		sessionFactory= MyHibernateUtil.getSessionFactory();
		if (sessionFactory != null)
			System.out.println("sessionFactory Obtained!!!");
		else
			System.err.println("Sorry Boss!! sessionFactory NOT Obtained!!!");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			insertEmployee();
			retriveEmployee();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			/*if (stmt != null)
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}*/
			if (sessionFactory != null)
				MyHibernateUtil.closeFactory();
		}

	}

	private static void insertEmployee() throws SQLException {
//step 1 : open session
		session= sessionFactory.openSession();
//step 2: begin tx (DML)
		transaction= session.beginTransaction();
//step 3: save employee
		System.out.println("Enter Employee Id : ");
		Integer empId = scan.nextInt();
		System.out.println("Enter Employee name : ");
		String empName = scan.next();
		System.out.println("Enter Employee sal : ");
		Double empSal = scan.nextDouble();
		employee= new Employee( empId,empName, empSal);
		empId = (Integer) session.save(employee);
//step 4: commit tx
		transaction.commit();
//step 5: close session
		session.close();
		if (empId > 0) {
			System.out.println(" Employee inserted successfully...  "+empId);
		} else {
			System.err.println("Sorry Boss , insert Not happened...");
		}
		/*System.out.println("\n*****************executing pre-compiled  query using preparedStatement object");
		// executing pre-compiled query using preparedStatement object
		String sql = "insert into myemp values(seq_myemp.nextval,?,?)";// ? -> Placeholder which values will be
																		// passed at runtime
		//// step 1: obtain preparedStament object by passing precomiple-query
		ps = conn.prepareStatement(sql);
		System.out.println("Enter Employee name : ");
		String name = scan.next();
		System.out.println("Enter Employee sal : ");
		Double sal = scan.nextDouble();
		//// step 2: set the value for the place holders
		ps.setString(1, name);// enter the value for 1st placeholder
		ps.setDouble(2, sal);// enter the value for 2nd placeholder
		//// step 3: execute the ps -> executeUdate for DML operation and executeQuery
		//// for select operation
		int noOfRec = ps.executeUpdate();// incase of ps never pass the sql query
		if (noOfRec > 0) {
			System.out.println(noOfRec + " , inserted successfully...");
		} else {
			System.err.println("Sorry Boss , insert Not happened...");
		}
		// executing simple select query using statement object
		System.out.println("\n*****************executing simple select query using statement object");*/
	}

	// executing simple select query using statement object
	private static void retriveEmployee() throws SQLException {
//step 1 : open session
		session= sessionFactory.openSession();		
//step 3: retrieve employee record
		Employee employeeFound = (com.lnt.day18_hibernate.employee.client.Employee) session.get(Employee.class, employee.getEmpId());
				//session.get returns Object
//step 5: close session
		session.close();
		if (employeeFound !=null) {
			System.out.println(" Employee Record Found..."+employeeFound);
		} else {
			System.err.println("Sorry Boss , Employee Record Not Found...");
		}
		// lets execute simple sql query
		/*String sql = "select * from myemp";

		// obatining statement object by invoking createStatement method of Connection
		// interface
		stmt = conn.createStatement();
		rs = stmt.executeQuery(sql);
		// executeQuery method of Statement interface is used to execute Select query
		// and returns ResultSet
		// executeUpdate method of Statement interface is used to execute
		// insert/update/delete query and returns int
		// iterate through ResultSet ,till it has next value
		Employee emp = null;
		while (rs.next()) {
			// we can get the column value with the help of passing columnIndex or
			// columnName
			// columnIndex starts with 1
			// emp=new Employee(rs.getInt(1),rs.getString("emp_name"),rs.getDouble(3));
			emp = new Employee();
			emp.setEmpId(rs.getInt(1));
			emp.setEmpName(rs.getString("emp_name"));
			emp.setEmpSal(rs.getDouble(3));
			// getting the column value from DB and setting it to the employee object
			System.out.println(emp);
		}*/
	}
}