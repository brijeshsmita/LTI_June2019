package com.lnt.hb.joined.model.emp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
@Entity
@Table(name="MY_MGR_JOINED1")
@PrimaryKeyJoinColumn(name="MGR_ID") 
public class Manager extends Employee {
	private static final long serialVersionUID = 156989306165097056L;
	
	@Column(name="BONUS")
	private double bonus;
	
	public Manager() {
		// TODO Auto-generated constructor stub
	}

	public Manager(String empName, Double empSal, double bonus) {
		super(empName, empSal);
		this.bonus = bonus;
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	@Override
	public String toString() {
		return "Manager [bonus=" + bonus + ", getEmpId()=" + getEmpId() + ", getEmpName()=" + getEmpName()
				+ ", getEmpSal()=" + getEmpSal() + "]";
	}
	
}
