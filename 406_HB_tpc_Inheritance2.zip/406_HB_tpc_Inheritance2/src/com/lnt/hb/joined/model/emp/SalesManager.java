package com.lnt.hb.joined.model.emp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
@Entity
@Table(name="MY_SMGR_JOINED1")
@PrimaryKeyJoinColumn(name="SMGR_ID") 
public class SalesManager extends Manager {
	private static final long serialVersionUID = -2740806103196113103L;
	
	@Column(name="COMM")
	private double comm;
	public SalesManager() {
		// TODO Auto-generated constructor stub
	}
	

	public SalesManager(String empName, Double empSal, double bonus, double comm) {
		super(empName, empSal, bonus);
		this.comm = comm;
	}


	public double getComm() {
		return comm;
	}
	public void setComm(double comm) {
		this.comm = comm;
	}


	@Override
	public String toString() {
		return "SalesManager [comm=" + comm + ", getBonus()=" + getBonus() + ", getEmpId()=" + getEmpId()
				+ ", getEmpName()=" + getEmpName() + ", getEmpSal()=" + getEmpSal() + "]";
	}

	
	
}
