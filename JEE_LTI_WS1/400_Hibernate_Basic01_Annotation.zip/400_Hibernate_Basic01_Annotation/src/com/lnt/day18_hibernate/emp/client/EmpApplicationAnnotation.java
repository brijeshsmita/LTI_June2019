package com.lnt.day18_hibernate.emp.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.lnt.day18_hibernate.emp.model.Employee;

public class EmpApplicationAnnotation {
	public static void main(String[] args) {
		// Object which need to be persisted
		Employee e1 = new Employee(103L, "Yara", 999.99, "yara@gmail.com");

		// step 1 : obtain session Factory
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		// by default will pick up the configuration detais from
		// hibernate.cfg.xml file
		// keep ur xml file in src..
		Session session = null;
		Transaction tx = null;
		try {
			// //step 2 : open session
			session = factory.openSession();
			// step 3 : In case of DML operations (Data manipulation insert
			// update and delete)
			// then begin transactions
			tx = session.beginTransaction();
			// step 4 : saving the employee -insert/create
			Long empId = (long) session.save(e1);
			System.out.println(" Employee record inserted with Id : " + empId);
			// step 5 : committing tx
			tx.commit();

			// Step 6 : DB operation -get (retrieve)
			Employee emp = (Employee) session.get(Employee.class,empId);// return object

			// Step 7 : beginTransaction for delete operation
			tx = session.beginTransaction();

			// Step 8 : DB operation -remove(delete)
			session.delete(emp);

			// Step 9 : commit the tx
			tx.commit();
			//Step 10 :close the session
			session.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			if (tx != null)
				tx.rollback();
		} finally {
			if (factory != null)
				//Step 11 :close the sessionFactory
				factory.close();
		}
	}
}

// Create a new Configuration ,
// for current application which has specific information about properties and
// mapping documents to be used
// With configure() API method use the mappings and properties specified in an
// application resource named hibernate.cfg.xml .

// if class is employee file name should be employee.hbm.xml... automatically
// configuration().configure() method takes data from this file

// creating session is lightweight process, multiple sessions can be created and
// no need to bother deallocation.

// buildSessionFactory(); method depricated in hibernate 4
// suggesting to use alternative ServiceRegistry object
/*
 * private static SessionFactory sessionFactory; private static ServiceRegistry
 * serviceRegistry; Configuration configuration = new Configuration();
 * configuration.configure(); serviceRegistry = new
 * ServiceRegistryBuilder().applySettings(configuration.getProperties()).
 * buildServiceRegistry(); sessionFactory =
 * configuration.buildSessionFactory(serviceRegistry);
 * 
 */
