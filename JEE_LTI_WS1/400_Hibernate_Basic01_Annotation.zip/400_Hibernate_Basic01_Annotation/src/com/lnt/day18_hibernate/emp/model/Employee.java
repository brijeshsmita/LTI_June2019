/**
 * 
 */
package com.lnt.day18_hibernate.emp.model;

import javax.persistence.Column;
import javax.persistence.Entity;//JPA
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Smita B Kumar
 *
 */
@Entity//class
@Table(name="MY_EMP")//table
public class Employee {
	//primary key column
	@Id
	@Column(name="EMP_ID")
	private Long empId;
	
	@Column(name="EMP_NAME")
	private String empName;
	
	@Column(name="EMP_SAL")
	private Double empSal;
	
	@Column(name="EMAIL")
	private String email;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", email=" + email + "]";
	}

	public Employee(Long empId, String empName, Double empSal, String email) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.email = email;
	}

	public Employee(String empName, Double empSal, String email) {
		super();
		this.empName = empName;
		this.empSal = empSal;
		this.email = email;
	}
	
}





