 create table  my_customer
  (	
		cust_Id float,
		cust_Name varchar(20),
		emails varchar(20),
		phone_nos varchar(20)
 );
 
 
 