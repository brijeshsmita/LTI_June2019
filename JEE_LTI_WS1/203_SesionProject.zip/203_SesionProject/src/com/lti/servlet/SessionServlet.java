package com.lti.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionServlet
 */
@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//how to obtain session
		HttpSession session = request.getSession(true);
		//by default getSession is true
		//we can set it to false
		//true- if session exists then ,return the same session else return new session
		//false- if session exists then ,return the same session else return null
		PrintWriter pw = response.getWriter();
		//step 4: write the response
		pw.println("<h1> Session Id :  , "+session.getId());
		pw.println("<h1> Session Creation Time :  , "+session.getCreationTime());
		pw.println("<h1> Session Last Access Time :  , "
		+session.getLastAccessedTime());
		session.setMaxInactiveInterval(10);
		pw.println("<h1> Session Creation Time :  , "+session.getCreationTime());
		response.setIntHeader("Refresh", 10);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
