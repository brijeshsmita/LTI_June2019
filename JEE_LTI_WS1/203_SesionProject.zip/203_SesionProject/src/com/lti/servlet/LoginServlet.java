package com.lti.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//step 1: //handle request -read the request parameter
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		//step 2 : set the response content type (response format)
		response.setContentType("text/html");
		//step 3: obtain the PrintWriter
		PrintWriter pw = response.getWriter();
		RequestDispatcher rd=null;
		//RD is used for inter-servlet communication
		//it is server side redirection - 
		//therefore the request uri will be same
		//and the forwarded or included request will treated as same request
		if(username.equals("admin")&& password.equals("admin")) {
			//how to obtain session
			HttpSession session = request.getSession();
			session.setMaxInactiveInterval(5);//60 seconds
		//step 4: write the response
			//set the username at session scope
			session.setAttribute("sessionUser", username);
			response.sendRedirect("WelcomeServlet");			
			/*pw.println("<h1 style='color:green'>Login Successful !!</h1>");
			rd=request.getRequestDispatcher("WelcomeServlet");
			rd.forward(request, response);*/
			//only the forwarded component will display the final output
		}else {
			pw.println("<h1  style='color:red'> Invalid Credentials , "
					+ "Kindly Re-Login </h1> "
					+ "...Project Context Root Path  :  "+request.getContextPath());
			rd=request.getRequestDispatcher("login.jsp");
			rd.include(request, response);
			//all the included component will display the final output
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
