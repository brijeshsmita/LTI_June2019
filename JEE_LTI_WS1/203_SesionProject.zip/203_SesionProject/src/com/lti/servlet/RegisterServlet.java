package com.lti.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		//response.setContentType("text/html");
	/*	String fname= request.getParameter("firstname");*/
		String [] checkBoxValues = request.getParameterValues("skill");
		out.println("Checkbox values of Skills : ");
		for(String s:checkBoxValues)
			out.print(s+",");
		Enumeration<String> parameterNames 
		= request.getParameterNames();				
		out.println("<hr><table align='center' border=2>");
		while(parameterNames.hasMoreElements()){
			String paraName=parameterNames.nextElement();
			out.println("<tr><td>"+paraName.toUpperCase()+"</td><td>");		
			String [] paraValues=request.getParameterValues(paraName);
			for(int i=0;i<paraValues.length;i++){
				String paraValue=paraValues[i];
				out.println(paraValue.toUpperCase()+" ");				
			}
			out.println("</td></tr>");
		}		
	}
}
