/**
 * 
 */
package com.lti.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * @author Smita B Kumar
 *
*/
public class LifeCycleServlet extends GenericServlet {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("destroy is invoked only once....");
		super.destroy();		
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);//must call super init
		System.out.println("init is invoked only once....");
		ServletContext application = config.getServletContext();
		System.out.println("Dev : "+application.getInitParameter("Developer")
		+"\nVersion : "+application.getInitParameter("Version"));
		System.out.println(
				"****Servlet Specific ServletConfig Initialization parameter"
				+ "Dev : "+config.getInitParameter("ServletDeveloper"));
	}

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("Service is invoked for ervery request....");
		//step 2 : set the response content type (response format)
				response.setContentType("text/html");
				//step 3: obtain the PrintWriter
				PrintWriter pw = response.getWriter();
				//step 4: write the response
				pw.println("<h1>Life Cycle Servlet </h1>"
						+ "<hr> <a href='index.jsp'>Home Page</a>");
	}

}
