package com.lti.filter;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class TimeFilter
 */
@WebFilter("/*")//any request
public class TimeFilter implements Filter {
	private static int reqCount;
//init(FilterConfig )
	//doFilter(ServletRequest req ,ServletResponse resp,FilterChain filterChain)
		//throws IOException,ServletException
	//destroy()
    /**
     * Default constructor. 
     */
    public TimeFilter() {
        //System.out.println("TimeFilter instantiated...only once");
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		//System.out.println("TimeFilter destroyed...only once");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		//step 1 :pre-processing of request
		long timeIn=System.currentTimeMillis();
		reqCount++;
		request.setAttribute("noOfHits", reqCount);
		System.out.println("\n*******TimeFilter process req at :"
				+LocalDateTime.now());//now() method provides current Date and time
chain.doFilter(request, response);
		//step 2 : doFilter forward the req, resp to the next component in the chain
		long timeOut=System.currentTimeMillis();//current time in milli seconds
		System.out.println("----TimeFilter process response at :"
					+LocalDateTime.now());
		long totalProcessingTime=timeOut-timeIn;
		System.out.println("----TimeFilter totalProcessingTime : "+totalProcessingTime+" milli seconds");
		
		
		//step 3 :post-processing of response
	}
	public void init(FilterConfig fConfig) throws ServletException {
		//System.out.println("TimeFilter init()...only once");
	}

}
