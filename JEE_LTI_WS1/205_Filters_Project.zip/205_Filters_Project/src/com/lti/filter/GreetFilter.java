package com.lti.filter;

import java.io.IOException;
import java.time.LocalDateTime;

import java.time.LocalDate;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class TimeFilter
 */
//@WebFilter("/*")//any request
public class GreetFilter implements Filter {
//init(FilterConfig )
	//doFilter(ServletRequest req ,ServletResponse resp,FilterChain filterChain)
		//throws IOException,ServletException
	//destroy()
    public GreetFilter() {
       // System.out.println("GreetFilter instantiated...only once");
    }
	public void destroy() {
		//System.out.println("GreetFilter destroyed...only once");
	}

	public void doFilter(ServletRequest request, ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		
		//step 1 :pre-processing of request
		
		System.out.println("***GreetFilter pre-processing Request...saying Hello "+request.getRemoteHost());
		chain.doFilter(request, response);
		//step 2 : doFilter forward the req, resp to the next component in the chain
		long timeOut=System.currentTimeMillis();
		//step 3 :post-processing of response
		System.out.println("***GreetFilter post-processing Response...saying Bye Bye "+request.getRemoteHost());
	}
	public void init(FilterConfig fConfig) throws ServletException {
		//System.out.println("GreetFilter init()...only once");
	}
}
