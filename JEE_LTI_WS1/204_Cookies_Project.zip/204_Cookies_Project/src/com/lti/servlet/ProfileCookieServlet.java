package com.lti.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProfileCookieServlet
 */
@WebServlet("/ProfileCookieServlet")
public class ProfileCookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		Cookie [] cookies = request.getCookies();
		pw.println("<h1>Profile Info from Cookies </h1><hr>"
				+ "<a href='LogoutCookieServlet'>Logout Page</a><hr><table>");
		for(Cookie c1 :cookies) {
			pw.println("<tr><td>"+c1.getName()+"</td>"
					+ "<td>"+c1.getValue()+"</td></tr>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
