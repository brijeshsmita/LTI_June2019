package com.lti.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieServlet
 */
@WebServlet("/CookieServlet")
public class CookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		//step 1 : create cookie object
		Cookie c1 = new Cookie("c1_name", username);
		Cookie c2 = new Cookie("c1_pass", password);
		Cookie c3 = new Cookie("c1_phone", "7738206222");
		//step 2 : setting the age of the cookie
		c1.setMaxAge(60*60);c2.setMaxAge(5);c3.setMaxAge(5);
		//step 3 : add cookie to the response obj
		response.addCookie(c1);response.addCookie(c2);response.addCookie(c3);
		
		response.sendRedirect("ProfileCookieServlet");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
