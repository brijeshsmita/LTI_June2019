package com.lti.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
//@WebServlet annotation is used to configure the class as Servlet 
//with the published name 
@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    //never override service in case of HttpServlet
	/*@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Service handling req and resp....");
		//if service is overridden in HttpServlet then 
		//we have to give explicit call to doPost or doGet method
		doPost(request, response);
	}*/
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    //FirstServlet- servlet
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//generate dynamic response -write and in which format
		//step 1: //handle request -read
		String username= request.getParameter("username");
		//step 2 : set the response content type (response format)
		response.setContentType("text/html");
		//step 3: obtain the PrintWriter
		PrintWriter pw = response.getWriter();
		//step 4: write the response
		pw.println("<h1> Welcome , "+username+"</h1>"
				+ "<hr> <a href='input.jsp'>Input Page</a>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
