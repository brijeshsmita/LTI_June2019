package com.lti.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RequestDemoServlet
 */
@WebServlet(urlPatterns = { "/RequestDemoServlet", "/ReqMethodDemo", "/req" })
public class RequestDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<h1 style='color:blue'><B>Request Context Path : </B>" + request.getContextPath() + "<BR>");
		out.println("<B>Request Method : </B>" + request.getMethod() + "<BR>");
		out.println("<B>Request Protocol : </B>" + request.getProtocol() + "<BR>");
		out.println("<B>Request URI : </B>" + request.getRequestURI() + "<BR>"
				+ "<table border='1'>");
		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String headerName = (String) headerNames.nextElement();
			out.println("<TR><TD>" + headerName);
			out.println(" </TD>   <TD>" + request.getHeader(headerName)+"</TD></TR>");
		}
		out.println("</table></h1>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
