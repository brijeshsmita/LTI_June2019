package com.lti.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ResponseServletMethod
 */
@WebServlet("/ResponseServletMethod")
public class ResponseServletMethod extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResponseServletMethod() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.println("<h1 style='color:blue'><B>Request Context Path : </B>" + request.getContextPath() + "<BR>");
		String username="Smita";
		request.setAttribute("username", username);
		ServletContext application = request.getServletContext();
		//set application level parameter
		application.setAttribute("appUser", username);
		
		HttpSession session = request.getSession();
		//set session level parameter
		session.setAttribute("sessionUser", username);
		//to set the request level attribute parameter
		RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
		rd.forward(request, response);
		//client side re-direction
		//response.sendRedirect("welcome.jsp");
		//it will create a new request
		//the request uri will be changed
		//or a fresh url/request will be created
		//we can re-direct to any url
		//response.sendRedirect("http://www.google.co.in");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
