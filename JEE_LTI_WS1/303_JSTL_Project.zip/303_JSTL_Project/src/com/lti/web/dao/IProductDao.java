/**
 * 
 */
package com.lti.web.dao;

import java.util.List;

import com.lti.web.model.Product;

/**
 * @author Smita B Kumar
 *
 */
public interface IProductDao {
	List<Product> getProductList();
}
