/**
 * 
 */
package com.lti.web.service;

import java.util.ArrayList;
import java.util.List;

import com.lti.web.dao.IProductDao;
import com.lti.web.dao.ProductDao;
import com.lti.web.model.Product;

/**
 * @author Smita B Kumar
 *
 */
//accepting request from controller
		//validating the request
		//performing cerating calculation if required
		//then call dao and return to controller
public class ProductService implements IProductService {
	private IProductDao productDao= new ProductDao();
	/* (non-Javadoc)
	 * @see com.lti.web.service.IProductService#getProductList()
	 */
	@Override
	public List<Product> getProductList() {
		
		return productDao.getProductList();
	}

}
