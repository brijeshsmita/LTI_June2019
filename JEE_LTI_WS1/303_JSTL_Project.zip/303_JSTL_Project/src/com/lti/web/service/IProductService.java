/**
 * 
 */
package com.lti.web.service;

import java.util.List;

import com.lti.web.model.Product;

/**
 * @author Smita B Kumar
 *
 */
public interface IProductService {
	List<Product> getProductList();
}
