package com.lnt.hb.tcp.model.emp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="MY_MGR_TPC1")
/*@AttributeOverrides(
		{
			@AttributeOverride(name="empId" ,column=@Column(name="EMP_ID")),
			@AttributeOverride(name="empName" ,column=@Column(name="EMP_NAME")),
			@AttributeOverride(name="empSal" ,column=@Column(name="EMP_SAL")),
		}
		)*/
public class Manager extends Employee {
	private static final long serialVersionUID = 156989306165097056L;
	
	@Column(name="BONUS")
	private double bonus;
	
	public Manager() {
		// TODO Auto-generated constructor stub
	}

	public Manager(String empName, Double empSal, double bonus) {
		super(empName, empSal);
		this.bonus = bonus;
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	@Override
	public String toString() {
		return "Manager [bonus=" + bonus + ", getEmpId()=" + getEmpId() + ", getEmpName()=" + getEmpName()
				+ ", getEmpSal()=" + getEmpSal() + "]";
	}
	
}
