/**
 * 
 */
package com.lnt.hb.employee.model;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/** * @author brije * */
@Entity
@Table(name="my_emp")
@NamedQueries({
	@NamedQuery(name="LIST_EMP",query="from Trainee"),
	@NamedQuery(name="FIND_BY_EMP_NAME",
	query="from Trainee e where e.empName=:empName")
})
public class Employee implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)//hibernate will generate the PK id
	@Column(name="emp_id")
	private Integer empId;
	@Column(name="emp_name")
	private String empName;
	@Column(name="emp_sal")
	private Double empSal;
	// constructors,getters and setters,toSTring(), equals(),hashCode()
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(Integer empId, String empName, Double empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}public Employee(String empName, Double empSal) {
		super();
		this.empName = empName;
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Trainee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}

}
