/**
 * 
 */
package com.lnt.hb.employee.client;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;


import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.NamedQuery;

import com.lnt.hb.employee.model.Employee;
import com.lnt.hb.util.HibernateUtil;

/**
 * @author brije
 *
 */
public class NativeSqlQueryClient {
	private static SessionFactory sessionFactory;
	private static Session session;
	private static Transaction transaction;
	private static Employee employee ;
	private static Query query;
	/*private static Connection conn;
	private static Statement stmt = null;
	private static PreparedStatement ps = null;
	private static ResultSet rs = null;*/
	private static Scanner scan = new Scanner(System.in);
	static {
		/*conn = MyConnection.getConn();*/
		sessionFactory= HibernateUtil.getSessionFactory();
		if (sessionFactory != null)
			System.out.println("sessionFactory Obtained!!!");
		else
			System.err.println("Sorry Boss!! sessionFactory NOT Obtained!!!");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			session=sessionFactory.openSession();
			//tx is mandatory for DML operations
			//transaction= session.beginTransaction();
			int empId=3;
			String empName="Ria";
			double empSal=111.00;
		//	session.save(new Trainee(empId,empName , empSal));
		//	transaction.commit();
			//list all the employee records-HQL
			SQLQuery sqlQuery= session.createSQLQuery("select * from my_emp");
			System.out.println("*************************List of All Employees******************************");
			List<Employee> empList=sqlQuery.list();
			empList.forEach((e1)->System.out.println(e1));//java 8 forEach and lambda
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			if (sessionFactory != null)
				HibernateUtil.closeFactory();
		}

	}
}