/**
 * 
 */
package com.lnt.hb.employee.client;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lnt.hb.employee.model.Employee;
import com.lnt.hb.util.HibernateUtil;

/**
 * @author brije
 *
 */
public class HqlClient {
	private static SessionFactory sessionFactory;
	private static Session session;
	private static Transaction transaction;
	private static Employee employee ;
	private static Query query;
	/*private static Connection conn;
	private static Statement stmt = null;
	private static PreparedStatement ps = null;
	private static ResultSet rs = null;*/
	private static Scanner scan = new Scanner(System.in);
	static {
		/*conn = MyConnection.getConn();*/
		sessionFactory= HibernateUtil.getSessionFactory();
		if (sessionFactory != null)
			System.out.println("sessionFactory Obtained!!!");
		else
			System.err.println("Sorry Boss!! sessionFactory NOT Obtained!!!");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			session=sessionFactory.openSession();
			//tx is mandatory for DML operations
			//transaction= session.beginTransaction();
			int empId=3;
			String empName="Ria";
			double empSal=111.00;
		//	session.save(new Trainee(empId,empName , empSal));
		//	transaction.commit();
			//list all the employee records-HQL
			query= session.createQuery("from Trainee");
			System.out.println("*************************List of All Employees******************************");
			List<Employee> empList=query.list();
			empList.forEach((e1)->System.out.println(e1));//java 8 forEach and lambda
			
			//list all the employee records-HQL
			query= session.createQuery("from Trainee e where e.empName=:empName");
			query.setString("empName", empName);
			System.out.println("*************************Trainee with name Sia******************************");
		    query.setMaxResults(1);
			Employee empFound= (Employee) query.uniqueResult();
			if(empFound!=null)			System.out.println("***empFound with name Sia .."+empFound);//java 8 forEach and lambda
			else System.out.println("***emp NOT Found with name Sia ..");
			
			//list all the employee records-HQL
			query= session.createQuery("from Trainee e where e.empName=:empName "
					+ "  and e.empSal=:empSal");
			query.setString("empName", empName);
			query.setDouble("empSal", 999888.00);
			System.out.println("*************************Trainee with name Sia and Sal******************************");
		    query.setMaxResults(1);
		    empFound= (Employee) query.uniqueResult();
			if(empFound!=null)			
				System.out.println("***empFound with name Sia and sal 999888.00 .."+empFound);//java 8 forEach and lambda
			else System.out.println("***emp NOT Found with name Sia ..and sal condition");
			//list all the employee records-HQL order by clause
			query= session.createQuery("from Trainee e where e.empSal>99 order by e.empSal");
			System.out.println("*************************List of All Employees Order By Sal******************************");
			empList=query.list();
			empList.forEach((e1)->System.out.println(e1));//java 8 forEach and lambda
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			if (sessionFactory != null)
				HibernateUtil.closeFactory();
		}

	}
}