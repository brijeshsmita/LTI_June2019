/**
 * 
 */
package com.lnt.hb.single_table.client;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lnt.hb.single_table.model.emp.Employee;
import com.lnt.hb.single_table.model.emp.Manager;
import com.lnt.hb.single_table.model.emp.SalesManager;
import com.lnt.hb.util.HibernateUtil;

/**
 * @author brije
 *
 */
public class SingleTableClient {
	private static SessionFactory sessionFactory;
	private static Session session;
	private static Transaction transaction;
	private static Employee employee ;
	private static Query query;
	/*private static Connection conn;
	private static Statement stmt = null;
	private static PreparedStatement ps = null;
	private static ResultSet rs = null;*/
	private static Scanner scan = new Scanner(System.in);
	static {
		/*conn = MyConnection.getConn();*/
		sessionFactory= HibernateUtil.getSessionFactory();
		if (sessionFactory != null)
			System.out.println("sessionFactory Obtained!!!");
		else
			System.err.println("Sorry Boss!! sessionFactory NOT Obtained!!!");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Employee e1 = new Employee("Sia", 99.00);
		Manager m1 = new Manager("Ram", 89.00, 10.00);
		SalesManager sm1 = new SalesManager("Laxman", 77.00, 10.0, 2.0);
		try {
			session=sessionFactory.openSession();
			//tx is mandatory for DML operations
			transaction= session.beginTransaction();
			session.save(e1);
			session.save(m1);
			session.save(sm1);
			transaction.commit();
			//list all the employee records-HQL
			query= session.createQuery("from Employee");//select * from Employee
			System.out.println("*************************List of All Employees******************************");
			List<Employee> empList=query.list();
			empList.forEach((emp)->System.out.println(emp));//java 8 forEach and lambda			
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			if (sessionFactory != null)
				HibernateUtil.closeFactory();
		}

	}
}