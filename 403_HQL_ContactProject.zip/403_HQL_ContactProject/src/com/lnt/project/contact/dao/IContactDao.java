/**
 * 
 */
package com.lnt.project.contact.dao;
import java.util.List;
import com.lnt.project.contact.entities.Contact;
import com.lnt.project.contact.exception.ContactException;
/** * @author Smita B Kumar * */
public interface IContactDao {
	public Integer addNewContact(Contact contact)throws ContactException;        //-Create   //add contact
	public List<Contact> getAllContacts()throws ContactException;                //-Retreive //Get All contact
	public Contact updateContact(Contact updatedContact)throws ContactException; //-Update   //edit contact
	public Contact removeContact(Contact contact)throws ContactException;		  //-Delete   //remove contact
	public Contact searchContactByName(String name)throws ContactException;      //-Search   //find contact
	public Contact searchContactById(Integer contactId)throws ContactException;  
	public Object terminateApplication()throws ContactException;
}
