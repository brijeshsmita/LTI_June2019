/**
 * 
 */
package com.lnt.project.contact.dao;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.lnt.project.contact.entities.Contact;
import com.lnt.project.contact.exception.ContactException;
import com.lnt.project.contact.util.HibernateUtil;
/** * @author Smita B Kumar * */
public class ContactDaoImpl implements IContactDao {
//Prep Work-Session Factory
	private static SessionFactory sessionFactory;
	private Session session;
	private Transaction tx;
	private Query query;
	static {
		sessionFactory=HibernateUtil.getSessionFactory();
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.dao.IContactDao#addNewContact(com.lnt.project.contact.entities.Contact)
	 */
	@Override
	public Integer addNewContact(Contact contact) throws ContactException {
		session= sessionFactory.openSession();
		tx=session.beginTransaction();
		Integer contactId=(Integer) session.save(contact);
		tx.commit();
		session.close();
		return contactId;
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.dao.IContactDao#getAllContacts()
	 */
	@Override
	public List<Contact> getAllContacts() throws ContactException {
		session= sessionFactory.openSession();
		query = session.createQuery("from Contact");
		List<Contact> contacts = query.list();
		session.close();
		return contacts;
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.dao.IContactDao#updateContact(com.lnt.project.contact.entities.Contact)
	 */
	@Override
	public Contact updateContact(Contact updatedContact) throws ContactException {
		session= sessionFactory.openSession();
		tx=session.beginTransaction();
		session.update(updatedContact);
		tx.commit();
		session.close();
		return updatedContact;
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.dao.IContactDao#removeContact(com.lnt.project.contact.entities.Contact)
	 */
	@Override
	public Contact removeContact(Contact contact) throws ContactException {
		session= sessionFactory.openSession();
		tx=session.beginTransaction();
		session.delete(contact);
		tx.commit();
		session.close();
		contact=null;
		return contact;
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.dao.IContactDao#searchContactByName(java.lang.String)
	 */
	@Override
	public Contact searchContactByName(String name) throws ContactException {
		session= sessionFactory.openSession();
		query = session.createQuery("from Contact c where c.firstName=:firstName");
		query.setParameter("firstName", name);
		query.setMaxResults(1);
		Contact contact = (Contact) query.uniqueResult();
		session.close();
		return contact;
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.dao.IContactDao#searchContactById()
	 */
	@Override
	public Contact searchContactById(Integer contactId) throws ContactException {
		session=sessionFactory.openSession();
		query=session.createQuery("from Contact where contactId=:contactId");//Contact is the name of the class
		query.setParameter("contactId", contactId);
		query.setMaxResults(1);
		Contact contact=(Contact) query.uniqueResult();
		session.close();
		return contact;
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.dao.IContactDao#terminateApplication()
	 */
	@Override
	public Object terminateApplication() throws ContactException {
		sessionFactory = HibernateUtil.closeFactory(sessionFactory);
		return sessionFactory;
	}
}
