/**
 * 
 */
package com.lnt.project.contact.service;
import java.util.List;
import com.lnt.project.contact.dao.ContactDaoImpl;
import com.lnt.project.contact.dao.IContactDao;
import com.lnt.project.contact.entities.Contact;
import com.lnt.project.contact.exception.ContactException;
/** * @author Smita B Kumar * */
public class ContactServiceImpl implements IContactService {
//prep work - Dao layer object
	//then in each method call the dao layer method and return to client
	private static IContactDao contactDao;
	static {
		contactDao=new ContactDaoImpl();
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.service.IContactService#addNewContact(com.lnt.project.contact.entities.Contact)
	 */
	@Override
	public Integer addNewContact(Contact contact) throws ContactException {		
		return contactDao.addNewContact(contact);
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.service.IContactService#getAllContacts()
	 */
	@Override
	public List<Contact> getAllContacts() throws ContactException {		
		return contactDao.getAllContacts();
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.service.IContactService#updateContact(com.lnt.project.contact.entities.Contact)
	 */
	@Override
	public Contact updateContact(Contact updatedContact) throws ContactException {		
		return contactDao.updateContact(updatedContact);
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.service.IContactService#removeContact(com.lnt.project.contact.entities.Contact)
	 */
	@Override
	public Contact removeContact(Contact contact) throws ContactException {		
		return contactDao.removeContact(contact);
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.service.IContactService#searchContactById(java.lang.Integer)
	 */
	@Override
	public Contact searchContactById(Integer contactId) throws ContactException {
		return contactDao.searchContactById(contactId);
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.service.IContactService#searchContactByName(java.lang.String)
	 */
	@Override
	public Contact searchContactByName(String name) throws ContactException {		
		return contactDao.searchContactByName(name);
	}
	/* (non-Javadoc)
	 * @see com.lnt.project.contact.service.IContactService#terminateApplication()
	 */
	@Override
	public Object terminateApplication() throws ContactException {		
		return contactDao.terminateApplication();
	}
}
